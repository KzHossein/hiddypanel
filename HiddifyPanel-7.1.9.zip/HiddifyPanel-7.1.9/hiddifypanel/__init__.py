from .VERSION import __version__, __release_date__
from . import Events
from .base import create_app, create_app_wsgi
from . import panel
__all__ = ["create_app", "create_app_wsgi"]

# application = create_app_wsgi()
